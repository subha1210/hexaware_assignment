package dao;
import entity.Employee;
import entity.Project;
import entity.Task;
import exception.EmployeeNotFoundException;
import exception.ProjectNotFoundException;

public interface IProjectRepository 
{
    boolean addEmployee(Employee emp);
    boolean addProject(Project project);
    boolean addTask(Task task);
    boolean assignProjectToEmployee(int empId, int projectId) throws EmployeeNotFoundException, ProjectNotFoundException;
    boolean assignTaskToEmployee(int empId, int taskId) throws EmployeeNotFoundException;
}