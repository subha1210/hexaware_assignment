package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Employee;
import entity.Project;
import entity.Task;
import util.DBConnUtil;
import exception.EmployeeNotFoundException;
import exception.ProjectNotFoundException;

public class ProjectRepositoryImpl implements IProjectRepository 
{

    private Connection conn;

    public ProjectRepositoryImpl() 
    {
        conn = DBConnUtil.getConnection();
    }

    @Override
    public boolean addProject(Project project) 
    {
        if (conn == null) 
        {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "INSERT INTO Project (id, projectName, description, startDate, status) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, project.getId());
            pstmt.setString(2, project.getProjectName());
            pstmt.setString(3, project.getDescription());
            pstmt.setDate(4, project.getStartDate());
            pstmt.setString(5, project.getStatus());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } 
        catch (SQLException e) 
        {
            System.out.println("Error in addProject(): " + e.getMessage());
            return false;
        }
    }

    public boolean addEmployee(Employee emp) 
    {
        if (conn == null) 
        {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "INSERT INTO Employee (id, name, designation, gender, salary, project_id) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, emp.getId());
            pstmt.setString(2, emp.getName());
            pstmt.setString(3, emp.getDesignation());
            pstmt.setString(4, emp.getGender());
            pstmt.setDouble(5, emp.getSalary());
            pstmt.setInt(6, emp.getProjectId());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error in addEmployee(): " + e.getMessage());
            return false;
        }
    }

    public boolean addTask(Task task) 
    {
        if (conn == null) 
        {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "INSERT INTO Task (task_id, task_name, project_id, employee_id, status) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, task.getTaskId());
            pstmt.setString(2, task.getTaskName());
            pstmt.setInt(3, task.getProjectId());
            pstmt.setInt(4, task.getEmployeeId());
            pstmt.setString(5, task.getStatus());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) 
        {
            System.out.println("Error in addTask(): " + e.getMessage());
            return false;
        }
    }

    public boolean assignProjectToEmployee(int empId, int projectId) throws EmployeeNotFoundException, ProjectNotFoundException {
        if (conn == null) 
        {
            System.out.println("Database connection not established.");
            return false;
        }

        if (!isEmployeeExists(empId)) 
        {
            throw new EmployeeNotFoundException("Employee with ID " + empId + " not found.");
        }

        if (!isProjectExists(projectId)) 
        {
            throw new ProjectNotFoundException("Project with ID " + projectId + " not found.");
        }

        String query = "UPDATE Employee SET project_id = ? WHERE id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, projectId);
            pstmt.setInt(2, empId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } 
        catch (SQLException e) 
        {
            System.out.println("Error in assignProjectToEmployee(): " + e.getMessage());
            return false;
        }
    }

    public boolean assignTaskToEmployee(int empId, int taskId) throws EmployeeNotFoundException 
    {
        if (conn == null) 
        {
            System.out.println("Database connection not established.");
            return false;
        }

        if (!isEmployeeExists(empId)) 
        {
            throw new EmployeeNotFoundException("Employee with ID " + empId + " not found.");
        }

        String query = "UPDATE Task SET employee_id = ? WHERE task_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, empId);
            pstmt.setInt(2, taskId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) 
        {
            System.out.println("Error in assignTaskToEmployee(): " + e.getMessage());
            return false;
        }
    }

    public boolean deleteEmployee(int empId) throws EmployeeNotFoundException 
    {
        if (conn == null) 
        {
            System.out.println("Database connection not established.");
            return false;
        }

        if (!isEmployeeExists(empId)) 
        {
            throw new EmployeeNotFoundException("Employee with ID " + empId + " not found.");
        }

        String query = "DELETE FROM Employee WHERE id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, empId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error in deleteEmployee(): " + e.getMessage());
            return false;
        }
    }

    public boolean deleteTask(int taskId) 
    {
        if (conn == null) 
        {
            System.out.println("Database connection not established.");
            return false;
        }

        String query = "DELETE FROM Task WHERE task_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, taskId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error in deleteTask(): " + e.getMessage());
            return false;
        }
    }

    public void getProjectsWithTasksByEmployeeId(int empId) throws EmployeeNotFoundException 
    {
        if (conn == null) 
        {
            System.out.println("Database connection not established.");
            return;
        }

        if (!isEmployeeExists(empId)) 
        {
            throw new EmployeeNotFoundException("Employee with ID " + empId + " not found.");
        }

        String query = """
            SELECT p.id AS project_id, p.projectName, t.task_id, t.task_name, t.status
            FROM Project p
            JOIN Task t ON p.id = t.project_id
            WHERE t.employee_id = ?
            """;

        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, empId);

            ResultSet rs = pstmt.executeQuery();
            boolean found = false;

            while (rs.next()) 
            {
                found = true;
                System.out.println("Project ID " + rs.getInt("project_id"));
                System.out.println("Project Name " + rs.getString("projectName"));
                System.out.println("Task ID " + rs.getInt("task_id"));
                System.out.println("Task Name " + rs.getString("task_name"));
                System.out.println("Task Status " + rs.getString("status"));
                System.out.println("-----");
            }

            if (!found) 
            {
                System.out.println("No task is found for the given employee ");
            }

        } catch (SQLException e) 
        {
            System.out.println("Error in getProjectsWithTasksByEmployeeId(): " + e.getMessage());
        }
    }

   
    private boolean isEmployeeExists(int empId) 
    {
        String query = "SELECT id FROM Employee WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, empId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) 
        {
            System.out.println("Error checking employee existence " + e.getMessage());
            return false;
        }
    }

    private boolean isProjectExists(int projectId) 
    {
        String query = "SELECT id FROM Project WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) 
        {
            pstmt.setInt(1, projectId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } 
        catch (SQLException e) 
        {
            System.out.println("Error checking project existence: " + e.getMessage());
            return false;
        }
    }
    public boolean projectExists(int projectId) 
    {
    String sql = "SELECT id FROM project WHERE id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) 
    {
        ps.setInt(1, projectId);
        try (ResultSet rs = ps.executeQuery()) 
        {
            return rs.next(); 
        }
    } catch (SQLException e) 
    {
        System.out.println("Error checking project existence: " + e.getMessage());
    }
    return false;
}
public boolean employeeExists(int empId) 
{
    String sql = "SELECT id FROM employee WHERE id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) 
    {
        ps.setInt(1, empId);
        try (ResultSet rs = ps.executeQuery()) 
        {
            return rs.next();
        }
    } 
    catch (SQLException e) 
    {
        System.out.println("Error checking employee existence " + e.getMessage());
        return false;
    }
}
public boolean taskExists(int taskId) 
{
    String sql = "SELECT task_id FROM task WHERE task_id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) 
    {
        ps.setInt(1, taskId);
        try (ResultSet rs = ps.executeQuery()) 
        {
            return rs.next();
        }
    } 
    catch (SQLException e) 
    {
        System.out.println("Error checking task existence: " + e.getMessage());
        return false;
    }
}


}
