package exception;

public class ProjectNotFoundException extends Exception
{
 public ProjectNotFoundException(String msg) 
 {
	super(msg);
 }
}

