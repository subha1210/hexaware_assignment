package mainmod;


import dao.HospitalServiceImpl;
import entity.Appointment;
import java.util.Scanner;
import java.util.List;



public class MainModule {
	

	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        HospitalServiceImpl service = new HospitalServiceImpl();

	        while (true) {
	            System.out.println("Hospital Management ");
	            System.out.println("1. View Appointment by ID");
	            System.out.println("2. View Appointments for Patient");
	            System.out.println("3. View Appointments for Doctor");
	            System.out.println("4. Schedule Appointment");
	            System.out.println("5. Update Appointment");
	            System.out.println("6. Cancel Appointment");
	            System.out.println("7. Exit");
	            System.out.print("Choice: ");
	            int ch = sc.nextInt();

	            try {
	                switch (ch) {
	                    case 1:
	                        System.out.print("Enter Appointment ID: ");
	                        int aid = sc.nextInt();
	                        System.out.println(service.getAppointmentById(aid));
	                        break;
	                    case 2:
	                        System.out.print("Enter Patient ID: ");
	                        int pid = sc.nextInt();
	                        List<Appointment> plist = service.getAppointmentsForPatient(pid);
	                        plist.forEach(System.out::println);
	                        break;
	                    case 3:
	                        System.out.print("Enter Doctor ID: ");
	                        int did = sc.nextInt();
	                        List<Appointment> dlist = service.getAppointmentsForDoctor(did);
	                        dlist.forEach(System.out::println);
	                        break;
	                    case 4:
	                        System.out.print("Enter Appointment ID: ");
	                        int id = sc.nextInt();
	                        System.out.print("Patient ID: ");
	                        int p = sc.nextInt();
	                        System.out.print("Doctor ID: ");
	                        int d = sc.nextInt();
	                        sc.nextLine();
	                        System.out.print("Date (yyyy-mm-dd): ");
	                        String date = sc.nextLine();
	                        System.out.print("Description: ");
	                        String desc = sc.nextLine();
	                        Appointment a = new Appointment(id, p, d, date, desc);
	                        System.out.println(service.scheduleAppointment(a) ? "Scheduled!" : "Failed!");
	                        break;
	                    case 5:
	                        System.out.print("Enter Appointment ID to update: ");
	                        int uid = sc.nextInt();
	                        System.out.print("New Patient ID: ");
	                        int up = sc.nextInt();
	                        System.out.print("New Doctor ID: ");
	                        int ud = sc.nextInt();
	                        sc.nextLine();
	                        System.out.print("New Date: ");
	                        String udate = sc.nextLine();
	                        System.out.print("New Description: ");
	                        String udesc = sc.nextLine();
	                        Appointment ua = new Appointment(uid, up, ud, udate, udesc);
	                        System.out.println(service.updateAppointment(ua) ? "Updated!" : "Failed!");
	                        break;
	                    case 6:
	                        System.out.print("Enter Appointment ID to cancel: ");
	                        int cid = sc.nextInt();
	                        System.out.println(service.cancelAppointment(cid) ? "Cancelled!" : "Failed!");
	                        break;
	                    case 7:
	                        System.out.println("Bye!");
	                        return;
	                    default:
	                        System.out.println("Invalid choice!");
	                }
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}
