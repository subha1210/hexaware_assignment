package exception;

public class PatientNumberNotFoundException extends Exception {
	

	private static final long serialVersionUID = 1L;

	public PatientNumberNotFoundException(String msg) 
    {
        super(msg);
    }
}

