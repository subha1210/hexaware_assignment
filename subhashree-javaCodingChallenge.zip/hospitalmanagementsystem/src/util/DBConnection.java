package util;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBConnection {


	    private static final String URL = "jdbc:mysql://localhost:3306/hospital";
	    private static final String USER = "root";
	    private static final String PASSWORD = "WJ28@krhps";
	    private static Connection con;

	    public static Connection getConnection() {
	        try {
	            if (con == null || con.isClosed()) {
	                Class.forName("com.mysql.cj.jdbc.Driver");
	                con = DriverManager.getConnection(URL, USER, PASSWORD);
	                System.out.println(" Connection established.");
	            }
	        } catch (Exception e) {
	            System.out.println(" Connection failed: " + e.getMessage());
	        }
	        return con;
	    }
	}



